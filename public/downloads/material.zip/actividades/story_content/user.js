function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5psWNg0EDA8":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

