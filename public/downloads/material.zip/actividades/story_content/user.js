function ExecuteScript(strId)
{
  switch (strId)
  {
      case "62hASC9FI2t":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

